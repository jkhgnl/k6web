# K6Web 多普勒文档

这是 K6Web 的多普勒专用使用说明，部署目标为 `https://doc.jkhgnl.top`。

## 本地预览

```bash
python3 -m http.server 8080
```

打开 <http://localhost:8080>。

## GitHub Pages 部署

该目录已作为独立仓库 `jkhgnl/k6web-docs` 的 `main` 分支发布，并配置了 `CNAME`：

```text
doc.jkhgnl.top
```

DNS 需要添加：

```text
类型：CNAME
名称：doc
目标：jkhgnl.github.io
```

GitHub Pages 构建完成后，在仓库 Settings → Pages 中开启 `Enforce HTTPS`。

## 来源

内容依据 F4HWN Doppler 固件源码中的 `App/app/doppler.h`、`doppler.c`、`doppler_mode.h`、`doppler_mode.c` 和 K6Web 配套协议实现整理，仅覆盖多普勒功能。
