(() => {
  const menu = document.getElementById('menuBtn');
  const side = document.getElementById('sidebar');
  const tabs = [...document.querySelectorAll('.doc-tab')];
  const panels = [...document.querySelectorAll('.doc-panel')];

  const HASH = { firmware: '#firmware', app: '#app', web: '#web' };

  function setDoc(type, updateUrl = true) {
    tabs.forEach(tab => {
      const active = tab.dataset.doc === type;
      tab.classList.toggle('active', active);
      tab.setAttribute('aria-selected', String(active));
    });
    panels.forEach(panel => {
      const active = panel.dataset.panel === type;
      panel.hidden = !active;
      panel.classList.toggle('active', active);
    });
    if (updateUrl) history.replaceState(null, '', HASH[type] || '#firmware');
    if (type !== 'app') setupSectionObserver();
    side?.classList.remove('open');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  tabs.forEach(tab => tab.addEventListener('click', () => setDoc(tab.dataset.doc)));
  const initial = ['#app', '#web'].includes(location.hash) ? location.hash.slice(1) : 'firmware';
  setDoc(initial, false);

  menu?.addEventListener('click', () => side?.classList.toggle('open'));
  side?.querySelectorAll('a[href^="#"]').forEach(a => a.addEventListener('click', () => side.classList.remove('open')));

  function setupSectionObserver() {
    const links = [...(side?.querySelectorAll('nav a') || [])];
    const sections = links.map(a => document.querySelector(a.getAttribute('href'))).filter(Boolean);
    if (!('IntersectionObserver' in window)) return;
    const observer = new IntersectionObserver(entries => entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      links.forEach(a => a.classList.toggle('active', a.getAttribute('href') === '#' + entry.target.id));
    }), { rootMargin: '-18% 0px -70% 0px' });
    sections.forEach(section => observer.observe(section));
  }
})();
